#!/bin/bash
#this script is currently designed to be run manually, not in unattended processes

is_revisioned_install() {
    REV_LABEL=$(kubectl get svc -n istio-system --selector=app=istiod -o jsonpath='{.items[*].spec.selector.istio\.io/rev}')
    if [ -z "$REV_LABEL" ];
    then
        IS_REVISIONED_INSTALL="false"

        echo "An unrevisioned version of istio is currently installed. Uninstall now? (y/n)"
        read -n 1 answer
        if [ "$answer" != "${answer#[Yy]}" ];
        then
            INSTALLED_ISTIO_VER="NONE"
            kubectl delete --ignore-not-found=true -f ./istio-yaml/istioctl-manifest.yaml
        fi

    else
        IS_REVISIONED_INSTALL="true"
    fi
}

get_current_lb_type() {
    INTERNAL_LB=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.metadata.annotations.service\.beta\.kubernetes\.io/azure-load-balancer-internal}')
    INTERNAL_SUBNET=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.metadata.annotations.service\.beta\.kubernetes\.io/azure-load-balancer-internal-subnet}')
}

get_current_ingress_ip() {
    INGRESS_SVC_TYPE=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.type}')
    INGRESS_IP=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
    echo "Current ingress IP is $INGRESS_IP"
}

get_current_install_ver() {
    prefix="control plane version: "
    INSTALLED_ISTIO_VER=$(istioctl version | grep "$prefix" | sed -e "s/^$prefix//")
}

get_latest_release() {
    REPO=$1
    curl --silent "https://api.github.com/repos/$REPO/releases/latest" | # Get latest release from GitHub api
        grep '"tag_name":' |                                            # Get tag line
        sed -E 's/.*"([^"]+)".*/\1/'                                    # Pluck JSON value
}

download_istio_ver() {
    #download the new version of istio
    curl -s -L https://istio.io/downloadIstio | ISTIO_VERSION=$ISTIO_VER TARGET_ARCH=x86_64 sh -
}

install_istio_ver() {
    echo "Installing istio..."
    #install istio without ingress ip
    ./istio-$ISTIO_VER/bin/istioctl install -f ./istio-yaml/control-plane.yaml --revision=$ISTIO_VER_STR --set values.gateways.istio-ingressgateway.runAsRoot=true --skip-confirmation
}

uninstall_istio_ver() {
    if [[ "${IS_REVISIONED_INSTALL}" == "true" ]];
    then
        istioctl x uninstall --revision $(echo "$1" | tr . -)
    fi
}

update_data_plane() {
    # all namespaces to update
    declare -a ns_list=("devops" "uid-dev-ui-app" "uid-dev-backend-service")
    for i in "${ns_list[@]}"
    do
        echo "Updating $i..."
        kubectl label namespace $i istio-injection- istio.io/rev=$ISTIO_VER_STR --overwrite=true
        kubectl rollout restart deployment -n $i `kubectl get deployment -n $i | awk '$3!=0 {print $1}'`
    done
}

update_ingress_gateway() {

    if [[ "${INGRESS_SVC_TYPE}" == "LoadBalancer" ]];
    then
        echo "Installing ingress-gateway with ingress IP $INGRESS_IP..."
        #install istio with ingress ip
        ./istio-$ISTIO_VER/bin/istioctl install -f ./istio-yaml/gateways.yaml --revision $ISTIO_VER_STR --set values.gateways.istio-ingressgateway.loadBalancerIP=$INGRESS_IP --skip-confirmation
    else
        echo "Installing ingress-gateway..."
        #install istio without ingress ip
        ./istio-$ISTIO_VER/bin/istioctl install -f ./istio-yaml/gateways.yaml --revision $ISTIO_VER_STR --skip-confirmation
    fi

    if [[ ! -z "$INTERNAL_LB" ]];
    then
        kubectl annotate service -n istio-system -l app=istio-ingressgateway,'istio.io/rev'=$ISTIO_VER_STR 'service.beta.kubernetes.io/azure-load-balancer-internal'=$INTERNAL_LB
    fi

    if [[ ! -z "$INTERNAL_SUBNET" ]];
    then
        kubectl annotate service -n istio-system -l app=istio-ingressgateway,'istio.io/rev'=$ISTIO_VER_STR 'service.beta.kubernetes.io/azure-load-balancer-internal-subnet'=$INTERNAL_SUBNET
    fi

    #wait for the new pod to come up
    sleep 10
    GW_VER=$(istioctl proxy-status | grep $(kubectl -n istio-system get pod -l app=istio-ingressgateway -o jsonpath='{.items..metadata.name}') | awk '{print $8}')
    echo "istio ingress gateway is now using revision $GW_VER"
}

update_add_ons() {
    #update all addons
    kubectl apply -f ./istio-addons/$ISTIO_VER/kiali.yaml
    kubectl apply -f ./istio-addons/$ISTIO_VER/prometheus.yaml
    kubectl apply -f ./istio-addons/$ISTIO_VER/jaeger.yaml
    kubectl apply -f ./istio-addons/$ISTIO_VER//grafana.yaml
    kubectl apply -f ./istio-addons/$ISTIO_VER/zipkin.yaml

    #update above exposed svcs
    #kubectl apply -f ./istio-yaml/kiali-as-service.yaml
    #kubectl apply -f ./istio-yaml/grafana-as-service.yaml
}

patch_istiod_svc() {
    kubectl get service -n istio-system -o json istiod-$ISTIO_VER_STR | jq '.metadata.name = "istiod" | del(.spec.clusterIP) | del(.spec.clusterIPs)' | kubectl apply -f -
}

get_kubernetes_context() {
    az account set --subscription 3001e23b-bb4a-4223-972e-f15869b0f48e
    az aks get-credentials --resource-group dev-jhbanking-rg --name dev-jhbanking-aks-cluster
}

get_kubernetes_context
get_current_install_ver
get_current_ingress_ip
get_current_lb_type
is_revisioned_install

if [ -z "$1" ];
then
    LATEST_ISTIO_VER=$(get_latest_release "istio/istio")
    echo "Current istio version is $INSTALLED_ISTIO_VER. The latest istio release is $LATEST_ISTIO_VER. Install it now? (y/n)"
    read -n 1 answer
    if [ "$answer" != "${answer#[Yy]}" ];
    then
        ISTIO_VER=$LATEST_ISTIO_VER;
    else
        echo "\nEnter the istio version to install:"
        read ISTIO_VER
    fi
else
    ISTIO_VER=$1
fi

ISTIO_VER_STR=$(echo "$ISTIO_VER" | tr . -)

download_istio_ver

echo "Installing istio $ISTIO_VER"
install_istio_ver

echo "Migrating Data plane to version $ISTIO_VER..."
update_data_plane

#update ingress-gateway
update_ingress_gateway

#update kiali, prometheus, grafana, etc
update_add_ons

# because of a bug in istio, we must manually patch existing istiod service to point to the new revision
# https://github.com/istio/istio/issues/28880
patch_istiod_svc

echo "istio $ISTIO_VER is now installed. Uninstall istio $INSTALLED_ISTIO_VER now? (WAIT FOR DEPLOYMENTS TO FINISH!) (y/n)"
read -n 1 answer
if [ "$answer" != "${answer#[Yy]}" ];
then
    uninstall_istio_ver $INSTALLED_ISTIO_VER
fi

echo "\nDone."
exit

#command to set the ingress ip
#kubectl patch svc istio-ingressgateway -n istio-system -p '{"spec": {"loadBalancerIP": "40.117.209.188"}}'
