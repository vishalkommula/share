[CmdletBinding()]
param (
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string] $WebHookUrl,

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string] $MessageTitle

    # This parameter should be passed via environment variables
    # when run in Azure Devops to prevent Task group from turning
    # the variable into a task parameter
    [Parameter(Mandatory=$false)]
    [string] $MessageText = $env:MessageText
)

Set-StrictMode -Version 6

$WebHookUrl = "$WebHookUrl".Trim()
$MessageText = "$MessageText".Trim()

if ([string]::IsNullOrWhiteSpace($MessageText) -or $MessageText -match '^\$\(') { 
  Write-Host "No Failure Message to Report"
  return 
}

if ([string]::IsNullOrWhiteSpace($WebHookUrl) -or $WebHookUrl -match '^\$\(' -or $WebHookUrl -ieq 'none') { 
  Write-Host "WebHook URL not provided" 
  return
}

$ReleaseUrl = "$($env:Release_ReleaseWebURL)"
if (![string]::IsNullOrWhiteSpace($ReleaseUrl)){
  $MessageText = "{0} Release URL: {1}" -f $MessageText, $ReleaseUrl
}

$Card = [pscustomobject]@{
   '@type' = 'MessageCard';
   '@context' = 'http://schema.org/extensions';
   themeColor = 'FF0000';
   summary = $MessageTitle;
   sections = @(
       [pscustomobject]@{ activityTitle = $MessageTitle; text = $MessageText }      
   )
}

$CardJson = $Card | ConvertTo-Json -Depth 10

Write-Host "Sending Teams Webhook Notification"

Invoke-RestMethod -Uri $WebhookUrl -Method Post -Body $CardJson -ContentType 'application/vnd.microsoft.teams.card.o365connector' -ea SilentlyContinue