#requires -Version 7.0
#requires -PSEdition Core
using namespace System.Management.Automation;

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string] $Canary,

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string] $Namespace,

    [Parameter(Mandatory=$false)]
    [ValidateRange([ValidateRangeKind]::Positive)]
    [int] $CanaryWaitSeconds = 30,

    [Parameter(Mandatory=$false)]
    [ValidateRange([ValidateRangeKind]::Positive)]
    [int] $CanaryTimeoutSeconds = 300,

    # In Azure Devops, the next three parameters must be
    # passed via environment variables (See below) so as
    # not to be turned into Task Group variables
    [Parameter(Mandatory=$false)]
    [string] $PriorDeployHash = $env:DEPLOY_PRIORHASH,

    [Parameter(Mandatory=$false)]
    [string] $PriorSpec = $env:CANARY_PRIORSPEC,

    [Parameter(Mandatory=$false)]
    [string] $PriorState = $env:CANARY_PRIORSTATE
)

Import-Module $PSScriptRoot/Canary-Helpers.psm1 -DisableNameChecking

Set-StrictMode -Version 6

# Set defaults so we don't need to specify them on every command invocation
$PSDefaultParameterValues = @{
    "*:Verbose"    = $VerbosePreference
    "*:Namespace"  = $Namespace
    "*:Canary"     = $Canary
    "*:Deployment" = $Canary
    "Throw-WithFailureMessage:VariableName" = "CanaryFailMessage"
}

$Start = [DateTime]::Now

$FirstTime = $PriorSpec -match "^((none)|\s*)$"
if ($PriorDeployHash -match "^((none)|\s*)$" ) { $PriorDeployHash = $null }

$WaitSecs = $FirstTime ? 0 : (Get-ClampedInteger -Value $CanaryWaitSeconds -Min 10 -Max 180)
# clamp between WaitSeconds and 15 minute Max
$TimeoutSecs = Get-ClampedInteger $CanaryTimeoutSeconds -Min ($FirstTime ? 30 : ($WaitSecs+1)) -Max 900

if (!$FirstTime) {
    # need to wait for Canary update to be recognized by Flagger
    Write-Host "Beginning $WaitSecs second WAIT for Flagger..."
    Start-Sleep -Seconds $WaitSecs
}

$Timeout = $Start.AddSeconds($TimeoutSecs)
$SecDiff = $TimeoutSecs - $WaitSecs

try {
    $NewDeployHash = Wait-ForDeployment -TimeSecs $SecDiff -ea Stop
} 
catch {
    Throw-WithFailureMessage "Deployment $Namespace/$Deployment has not become available... Canary progression cannot proceed"
}

$SameDeployHash = $PriorDeployHash -and $NewDeployHash -ieq $PriorDeployHash
$IsRedeployText = $SameDeployHash ? 'Yes' : 'No'

# flagger will not detect this state so we force an update
# that WILL trigger the deployment
if ($PriorState -ieq 'Failed' -and $SameDeployHash -and ($PriorSpec -eq (Get-CanarySpec -ea SilentlyContinue))) {

    $soFar = [int](([DateTime]::Now - $Start).TotalSeconds)
    $SecDiff = ([int]([Math]::Max($TimeoutSecs - $soFar, 30)))

    $patchYaml = @"
spec:
  template:
    metadata:
      labels:
        app.ecp.canary/force: '$([Guid]::NewGuid())'
"@

    Write-Warning "Prior Canary State was Failed and Deployment has not changed"
    Write-Warning "Adding Label to Deployment to force an update that Flagger will recognize"
    Write-Verbose $patchYaml

    $lut = Get-DeploymentUpdateTime -ea SilentlyContinue

    try {
        Patch-Deployment -N $Namespace -D $Canary -PatchYaml $patchYaml -ea Stop > $null
        Write-Host "Deployment successfully patched"
    } 
    catch {
        Throw-WithFailureMessage "Failed to patch Deployment $Namespace/$Deployment"
    }

    # Wait for K8s/Deployment/etc to recognize an update occured on the deployment
    # availability will turn to false at which point we can then wait for it
    Write-Host "Waiting for K8s to recognize deployment patch and begin roll-out..."
    while ($lut -eq (Get-DeploymentUpdateTime -ea SilentlyContinue) -and [DateTime]::Now -lt $Timeout) {
        Write-Verbose "Still Waiting..." ;
        Start-Sleep -Seconds 2
    }
    Write-Host "Roll-out has begun"

    # now, actually wait for the deployment to proceed
    try {
        $NewDeployHash = Wait-ForDeployment -TimeSecs $SecDiff -ea Stop
    } 
    catch {
        Throw-WithFailureMessage "Deployment $Namespace/$Deployment has not become available... Canary progression cannot proceed"
    }

    $SameDeployHash = $PriorDeployHash -and $NewDeployHash -ieq $PriorDeployHash
    $IsRedeployText = 'Yes, with new label'
}

$SecDiff = [int]([Math]::Max(0, [int](($Timeout - [DateTime]::Now).TotalSeconds)))

$WasInitialized = $PriorState -ieq 'Initialized'

# don't add 'Finalizing' into this list... only in the if/else chain below
# this way we loop until state is terminal and only allow Finalising in the 
# event that's what the state is at the end of the timeout.
$FinalStatusList = @('Failed','Succeeded')
if ($FirstTime) { $FinalStatusList += 'Initialized' }
elseif ($SameDeployHash -and $WasInitialized) {
    $FinalStatusList += 'Initialized'
}

Write-Host "Begin Wait for Canary Promotion"
Write-Host "Is First-Time Deployment: $FirstTime"
Write-Host "Is Re-Deployment: $IsRedeployText"
Write-Host "`tPrior Deployment Hash: $PriorDeployHash"
Write-Host "`tNew Deployment Hash: $NewDeployHash"
Write-Host "Wait Ends after $SecDiff seconds at $Timeout"

$Status = Get-CanaryStatus -ea SilentlyContinue
while ($Status -notin $FinalStatusList -and [DateTime]::Now -le $Timeout){
    Start-Sleep -Seconds 5
    $Status = Get-CanaryStatus -ea SilentlyContinue
}

$TimeoutMins = [Math]::Round( [Timespan]::FromSeconds($TimeoutSecs).TotalMinutes, 2).ToString("#,##0.##")

[string] $FailMessage = $null

if ($Status -ieq 'Failed') {
    $FailMessage = "Canary $Canary Failed"
} 
elseif ($Status -ieq 'Succeeded') {
    Write-Host "Canary $Canary Succeeded"
} 
elseif ($Status -ieq 'Finalising' -or $Status -ieq 'Finalizing'){
    Write-Host "Canary $Canary Status is '$Status' (allowed by policy)"
    Write-Warning "Canary Status for $Canary is '$Status' after $TimeoutMins minutes. This status is allowed and the release will continue."
}
elseif ($Status -ine 'Initialized') {
    $TargetStatus = $FirstTime ? 'Initialized' : "Succeeded"   
    $FailMessage = "Canary Status for $Canary has not progressed to $TargetStatus in the allotted time ($TimeoutMins minutes). Current status: $Status"
}
# Below Here - State: Initialized
elseif ($FirstTime) {
    Write-Host "Canary $Canary set to Initialized (first deployment)"
} 
elseif (-not ($WasInitialized -and ($PriorSpec -eq (Get-CanarySpec -ea SilentlyContinue)))) {
    $FailMessage = "Canary $Canary State stuck at Initialized. You may need to delete the 'primary' deployment"
} 
# Below Here - State: Initialized, Previously: Initialized and Prior Spec matches current spec
elseif ($SameDeployHash) {
    Write-Host "Canary $Canary State is Initialized (no change from Prior Deployment)"
} 
else {
    $FailMessage = "Canary $Canary state is still Initialized. Flagger has not recognized a new Specification. This may be OK if this is a re-deployment"
}

if ($FailMessage) {
    Throw-WithFailureMessage $FailMessage
}