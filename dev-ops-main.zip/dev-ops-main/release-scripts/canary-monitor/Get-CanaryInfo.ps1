#requires -Version 7.0
#requires -PSEdition Core
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string] $Canary,

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string] $Namespace
)

Import-Module $PSScriptRoot/Canary-Helpers.psm1 -DisableNameChecking

Set-StrictMode -Version 6

$PSDefaultParameterValues = @{
    "*:Verbose"   = $VerbosePreference
    "*:Namespace" = $Namespace
    "*:ErrorAction" = "SilentlyContinue"
}

$LastSpec  = Get-CanarySpec     -Canary     $Canary || "none"
$LastState = Get-CanaryStatus   -Canary     $Canary || "none"
$LastHash  = Get-DeploymentHash -Deployment $Canary || "none"

Write-PipelineVariable -Name PriorCanarySpec  -Value $LastSpec
Write-PipelineVariable -Name PriorCanaryPhase -Value $LastState
Write-PipelineVariable -Name PriorDeployHash  -Value $LastHash